/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projwekajavafx;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class FXMLWekaController implements Initializable {
    
    private String caminhoDados = "file:///D://Documents//NetBeansProjects//ProjWekaJavaFX//src//porjwekajavafx//BC_Wins.arff";
    private String classePrev;
    apiWeka dataset = new apiWeka(caminhoDados);
    private float valor0, valor1, valor2, valor3, valor4, valor5, valor6, valor7, valor8, valor9;

    @FXML
    private Button botaoResultado;

    @FXML
    private Label labelHeader;

    @FXML
    private Label labelRadius;

    @FXML
    private Label labelTexture;

    @FXML
    private Label labelPerimeter;

    @FXML
    private Label labelArea;

    @FXML
    private Label labelResultado;

    @FXML
    private TextField txtRadius;

    @FXML
    private TextField txtTexture;

    @FXML
    private TextField txtPerimeter;

    @FXML
    private TextField txtArea;

    @FXML
    private TextField txtResultado;

    @FXML
    private TextField txtSmoothness;

    @FXML
    private TextField txtCompactness;

    @FXML
    private TextField txtConcavity;

    @FXML
    private TextField txtConcavePoints;

    @FXML
    private TextField txtSymmetry;

    @FXML
    private TextField txtFractalDimension;

    @FXML
    private Label labelSmoothness;

    @FXML
    private Label labelCompactness;

    @FXML
    private Label labelConcavePoints;

    @FXML
    private Label labelSymmetry;

    @FXML
    private Label labelConcavity;

    @FXML
    private Label labelFractalDimension;

    @FXML
    private void handleButtonAction(ActionEvent event) throws Exception{
        dataset.leDados();
        
        valor0 = Float.parseFloat(txtRadius.getText());
        valor1 = Float.parseFloat(txtTexture.getText());
        valor2 = Float.parseFloat(txtPerimeter.getText());
        valor3 = Float.parseFloat(txtArea.getText());
        valor4 = Float.parseFloat(txtSmoothness.getText());
        valor5 = Float.parseFloat(txtCompactness.getText());
        valor6 = Float.parseFloat(txtConcavity.getText());
        valor7 = Float.parseFloat(txtConcavePoints.getText());
        valor8 = Float.parseFloat(txtSymmetry.getText());
        valor9 = Float.parseFloat(txtFractalDimension.getText());
        
        classePrev = dataset.InstanceBased(valor0, valor1, valor2, valor3, valor4, valor5, valor6, valor7, valor8, valor9);
        
        System.out.println("You clicked me!");
        
        txtResultado.setText(classePrev);
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}

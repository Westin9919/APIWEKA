/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projwekajavafx;

import java.util.Random;
import weka.core.Instances;
import weka.core.Instance;
import weka.core.converters.ConverterUtils.DataSource;
import weka.classifiers.trees.J48;
import weka.classifiers.Evaluation;
import weka.classifiers.lazy.IBk;
import weka.core.DenseInstance;
import weka.core.Attribute;

public class apiWeka {

    private String caminhoDados;
    private Instances dados;
	
    public apiWeka(String caminhoDados) {
    	this.caminhoDados = caminhoDados;
    }
	
    public void leDados() throws Exception {
    	DataSource fonte = new DataSource(caminhoDados);
		
    	dados = fonte.getDataSet();
		
    	if(dados.classIndex() == -1) {
            dados.setClassIndex(dados.numAttributes() - 1);
	}
    }
	
    public void imprimeDados() {
    	for(int i = 0; i < dados.numInstances(); i++) {
            Instance atual = dados.instance(i);
            System.out.println((i + 1) + ": " + atual + "\n");
	}
    }

    public void arvoreDeDecisaoJ48() throws Exception{
        J48 tree = new J48();
		
    	tree.buildClassifier(dados);
    	System.out.println(tree);
		
    	System.out.println("Avaliacao inicial: \n");
		
        Evaluation avaliacao;
        avaliacao = new Evaluation(dados);
		
        avaliacao.evaluateModel(tree, dados);
	System.out.println("--> Instancias corretas: " + avaliacao.correct() + "\n");
		
	System.out.println("Avaliacao cruzada: \n");
		
	Evaluation avalCruzada;
	avalCruzada = new Evaluation(dados);
		
	avalCruzada.crossValidateModel(tree, dados, 10, new Random(1));
	System.out.println("--> Instancias corretas CV: " + avalCruzada.correct() + "\n");
    } 
	
    public String InstanceBased(double valor0, double valor1, double valor2, double valor3, double valor4, double valor5, double valor6, double valor7, 
            double valor8, double valor9) throws Exception {
        IBk k3 = new IBk(3);
        k3.buildClassifier(dados);
		
        DenseInstance newInst = new DenseInstance(10);
        newInst.setDataset(dados);
		
        newInst.setValue(0,  valor0);
        newInst.setValue(1,  valor1);
        newInst.setValue(2,  valor2);
        newInst.setValue(3,  valor3);
        newInst.setValue(4,  valor4);
        newInst.setValue(5,  valor5);
        newInst.setValue(6,  valor6);
        newInst.setValue(7,  valor7);
        newInst.setValue(8,  valor8);
        newInst.setValue(9,  valor9);
		
        double pred = k3.classifyInstance(newInst);
		
        Attribute a = dados.attribute(10);
        String predClass = a.value((int) pred);
        
        return (predClass);
	
    }
	
}
